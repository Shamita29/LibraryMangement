from statistics import mode
from django.db import models

# Create your models here.

class Admindata(models.Model):
    adminName = models.CharField(max_length=50, null=False)
    adminEmail = models.CharField(max_length=100, primary_key=True, null=False)
    adminPass = models.CharField(max_length=50, null=False)


class Book(models.Model):
    bookIsbn = models.CharField(max_length=100, primary_key=True, null=False)
    bookName = models.CharField(max_length=100, null=False)
    bookCount = models.CharField(max_length=4, null=False)

    def __iter__(self):
        return self


class Student(models.Model):
    studName = models.CharField(max_length=100,null=False)
    studEmail = models.CharField(max_length=100, primary_key=True,null=False)
    studPass = models.CharField(max_length=100,null=False)

