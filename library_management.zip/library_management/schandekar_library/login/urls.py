from django.contrib import admin
from django.urls import path
from login import views

urlpatterns = [
    path("", views.home,name='home'),
    path("adminlogin/", views.adminlogin, name='adminlogin'),
    path("adminregister/", views.adminreg, name= 'adminregister'),
    path("adminlogout/", views.adminlogout, name="adminlogout"),
    path("studlogout/", views.studlogout, name="studlogout"),
    path("studlogin/", views.studlogin, name="studlogin"),
    path("studregister/", views.studregister, name = "studregister"),
    path("bookpage/", views.bookpage, name = "bookpage"),
    path("bookadd/", views.bookadd, name="bookadd"),
    path("bookview/", views.bookview, name="bookview"),
    path("bookAction/", views.bookAction, name="bookAction"),
    path("bookdel/<str:bookIsbn>/",views.bookdel, name="bookdel"),
    path("bookupdate/<str:bookIsbn>/",views.bookupdate, name="bookupdate"),
    path("update/<str:bookIsbn>", views.update, name="update"),

]