from audioop import reverse
from sqlite3 import IntegrityError
from urllib import request
from rest_framework.response import Response  

from django.shortcuts import render

from django.shortcuts import render, HttpResponse, HttpResponseRedirect

from login.models import Book
import mysql.connector as sql
from django.contrib import messages
from django.shortcuts import redirect

from django.template import loader
from django.shortcuts import get_object_or_404


from .models import *
username=''
useremail=''
userpass = ''
bookisbn=''
bookname=''
bookstatus=''
# Create your views here.

def home(request):
    return render(request, 'home.html')

def adminlogin(request):
        global username, useremail, userpass
        if request.method == "POST":
                m = sql.connect(host="localhost", user="root", password="root",database = 'mylib')
                cursor=m.cursor();
                d=request.POST
                for key,value in d.items():
                        if key=="email":
                                useremail = value
                        if key=="password":
                                userpass=value

                data = "select adminEmail, adminPass from login_admindata where adminEmail='{}' and adminPass='{}'".format(useremail, userpass)
                cursor.execute(data)
                data = tuple(cursor.fetchall())
                if data==():
                        messages.info(request, 'User doesnot exist.')
                        return redirect('adminlogin')

                else: 
                        useremail=""
                        username=""
                        userpass=""
                        return redirect('bookpage')
                
        return render(request, 'adminlogin.html')
 

def adminreg(request):
        global username, useremail, userpass
        if request.method == "POST":
                m = sql.connect(host="localhost", user="root", password="root",database = 'mylib')
                cursor=m.cursor();
                d=request.POST
                for key,value in d.items():
                        if key=="username":
                                username=value
                        if key=="useremail":
                                useremail = value
                        if key=="userpassword":
                                userpass=value

                check = "select * from login_admindata where adminEmail='{}'".format(useremail)
                cursor.execute(check)
                data = tuple(cursor.fetchall())
                if data==():
                        c="insert into login_admindata values('{}','{}','{}')".format(username,useremail,userpass)
                        cursor.execute(c)
                        m.commit()
                        messages.info(request, 'Registered successfully.')
                        useremail=""
                        username=""
                        userpass=""
                else:
                        messages.info(request, 'User email exist.')
                        return redirect('adminregister')
        
        return render(request, 'adminregister.html')

def adminlogout(request):
        return redirect('/')

def studlogout(request):
        return redirect('/')

def studlogin(request):
        global username, useremail, userpass
        if request.method == "POST":
                m = sql.connect(host="localhost", user="root", password="root",database = 'mylib')
                cursor=m.cursor()
                d=request.POST
                for key,value in d.items():
                        if key=="email":
                                useremail = value
                        if key=="password":
                                userpass=value

                data = "select studEmail, studPass from login_student where studEmail='{}' and studPass='{}'".format(useremail, userpass)
                cursor.execute(data)
                data = tuple(cursor.fetchall())
                if data==():
                        messages.info(request, 'User doesnot exist.')
                        return redirect('studlogin')

                else:                           
                        useremail=""
                        username=""
                        userpass=""
                        return redirect('bookview')
                
        return render(request, 'studentlogin.html')
 


def studregister(request):
        if request.method == "POST":
                m = sql.connect(host="localhost", user="root", password="root",database = 'mylib')
                cursor=m.cursor();
                d=request.POST
                for key,value in d.items():
                        if key=="first_name":
                                name=value
                        if key=="email":
                                studentemail = value
                        if key=="password":
                                password=value

                check = "select * from login_student where studEmail='{}'".format(studentemail)
                cursor.execute(check)
                data = tuple(cursor.fetchall())
                if data==():
                        c="insert into login_student values('{}','{}','{}')".format(name,studentemail,password)
                        cursor.execute(c)
                        m.commit()
                        messages.info(request, 'Registered successfully.')

                else:
                        messages.info(request, 'User email exist.')
                        return redirect('studregister')
        
        return render(request, 'studentregister.html')

def bookpage(request):
        return render(request, 'booksdata.html')

def bookadd(request):
        global bookisbn,bookname,bookstatus
        if request.method == "POST":
                m = sql.connect(host="localhost", user="root", password="root",database = 'mylib')
                cursor=m.cursor()
                d=request.POST
                for key,value in d.items():
                        if key=="bookisbn":
                                bookisbn = value
                        if key=="bookname":
                                bookname=value
                        if key=="bookstatus":
                                bookstatus=value
                                
                check = "select * from login_book where bookIsbn='{}'".format(bookisbn)
                cursor.execute(check)
                data = tuple(cursor.fetchall())
         
                if data==():
                        c="insert into login_book values('{}','{}','{}')".format(bookisbn,bookname,bookstatus)
                        cursor.execute(c)
                        m.commit()
                        bookstatus=""
                        bookname=""
                        bookisbn=""
                        messages.info(request, "book added successfully.")
                
                else:
                        messages.info(request, "ISBN exist")
                        return redirect("bookadd")
        return render(request, 'bookadd.html')


def bookview(request):
        books= Book.objects.all()

        return render(request, "booksview.html",{"books":books})
 
def bookAction(request):
        book= Book.objects.all()
        return render(request, 'bookaction.html',{"book":book})


def bookdel(request,bookIsbn):
        member = Book.objects.get(bookIsbn=bookIsbn)
        member.delete()
        return redirect('bookAction')
        
def bookupdate(request, bookIsbn):
        member = Book.objects.get(bookIsbn=bookIsbn)
        template = loader.get_template('bookupdate.html')
        context = {
                'mymember': member,
                }
        return HttpResponse(template.render(context, request))

def update(request, bookIsbn):
        global bookisbn,bookname,bookcount
        #template = loader.get_template('bookupdate.html')
        '''if request.method=="POST":
                bookstatus=request.POST("bookstatus")                
                data = Book.objects.get(bookId = bookId)
                data.bookVersion = bookstatus
                data.save()
                return redirect('bookAction')'''
        

        if request.method == "POST":
                m = sql.connect(host="localhost", user="root", password="root",database = 'mylib')
                cursor=m.cursor()
                d=request.POST
                for key, value in d.items():
                        if key=="bookstatus":
                                bookcount=value

                query="update login_book set bookCount='{}' where bookIsbn='{}'".format(bookcount,bookIsbn)
                cursor.execute(query)
                m.commit()
                return redirect('bookAction')
                
        return render(request, 'bookaction.html')

