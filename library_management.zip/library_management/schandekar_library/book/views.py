from django.shortcuts import render


# Create your views here.
def bookpage(request):
    return render(request, 'bookdata.html')

def bookadd(request):
    return render(request, 'bookadd.html')

def bookretrieve(request):
    return render(request, 'bookretrieve.html')

